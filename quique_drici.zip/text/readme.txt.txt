--- Membres du binôme:
Othman DRICI
Paul   QUIQUE

--- Choix de programmation:
	
- Un appel à la fonction "fonctionPrincipale()" lance le traitement du corpus.

- Le programme est subdivisé en fonctions avec un descriptif et leurs paramètres.

- /!\ L'importante taille mémoire de la matrice numpy nous a imposé de faire des choix
sur les textes. La matrice de la petite partie traitée pèse à elle seule 200Mb.